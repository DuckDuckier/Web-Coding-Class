import $ from 'https://cdn.skypack.dev/jquery';

$(document).ready(function () {
  $('#mostrar').click(function () {
    $('#caja').fadeIn();
  });

  $('#ocultar').click(function () {
    $('#caja').fadeOut();
  });

  $('#cambiar').click(function () {
    $('#caja').css({
      'background-color': 'salmon',
      'color': 'white',
      'font-weight': 'bold'
    });
  });
});
